package javax.main.model;

public interface Premios {
float primero = 0.6335f;
float segundo = 0.1665f;
float empresa = 0.2f;
}
