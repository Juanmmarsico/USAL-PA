package javax.main.model;

public interface Costo {
double descuento =100 - 8;
double promocion =100 - 5.5;

double calcularCostoTotalAlCheckOut();
}
