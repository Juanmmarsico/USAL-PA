package main.model;

public interface Costo {
double descuentoPorEfectivo = 0.95;
int excesoDistancia = 150;
double excesoCosto = 0.015;

double getCosto();
double costoTotal();
}
